<?php
$cat_id=0;
if(isset($_POST["cat_ID"]) && $_SERVER["REQUEST_METHOD"] == "POST")
{
    $cat_id = $_POST["cat_ID"];
}
$Allproducts = $conn->prepare("SELECT p.product_id, p.pro_name,  p.pro_price, p.cat_id, pi.pro_image
    FROM Products p
    JOIN Product_Images pi ON p.product_id = pi.product_id
    WHERE p.cat_ID = $cat_id
    GROUP BY p.product_id
    HAVING COUNT(pi.pro_image_id) = 1;
");


$Allproducts->execute();
$products = $Allproducts->fetchAll(PDO::FETCH_ASSOC);


if(empty($products)){
    $Allproducts = $conn->prepare("SELECT p.product_id, p.pro_name,  p.pro_price, p.cat_id, pi.pro_image
    FROM Products p
    JOIN Product_Images pi ON p.product_id = pi.product_id
    WHERE p.cat_ID = 7
    GROUP BY p.product_id
    HAVING COUNT(pi.pro_image_id) = 1;
");

$Allproducts->execute();
$products = $Allproducts->fetchAll(PDO::FETCH_ASSOC);

}
?>

<section class="best_seller_section">
    <h1>Products</h1>
    <h6>Explore our most popular products</h6>
    <div class="best_seller_cards">
        <?php foreach ($products as $product): ?>
            <form action="../productPage/product.php" method="post" style="display: inline-block;">
                <input type="hidden" name="productId" value="<?php echo htmlspecialchars($product['product_id']); ?>">
                <button type="submit" style="border: none;">
                    <div class="card">
                        <img src="../uploads/<?php echo htmlspecialchars($product['pro_image']); ?>" alt="" />
                        <div class="card-content">
                            <p class="product-name"><b><?php echo htmlspecialchars($product['pro_name']); ?></b></p>
                            <p class="price"><?php echo htmlspecialchars($product['pro_price']); ?> JOD</p>
                            <p class="add-to-cart"><b>Add to cart</b></p>
                        </div>
                    </div>
                </button>
            </form>
        <?php endforeach; ?>
    </div>
</section>