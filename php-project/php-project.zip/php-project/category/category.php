<?php include("../connection/connect.php")  ;?>
<?php include("../navbar/navbar.php");?>
<?php include("../cart/cart.php");?>
<?php include("./categoryCategory.php")  ;?>
<?php include("./categoryProducts.php")  ;?>
<?php include("../footer/footer.php");?>