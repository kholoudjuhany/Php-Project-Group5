<footer class="footer">
  <div class="container-fluid d-flex justify-content-center">
    <span class="text-muted d-block text-center fw-bold" >Copyright © Group 5</span>
  </div>
</footer>