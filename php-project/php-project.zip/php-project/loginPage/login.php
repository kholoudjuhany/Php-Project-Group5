<?php

session_start();

$host = 'localhost'; 
$dbname = 'pet_stuff';
$username = 'root'; 
$password = '';

$conn = new mysqli($host, $username, $password, $dbname);

// checking connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare('SELECT user_id, user_email, user_password, user_permission FROM users WHERE user_email = ?');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && $password === $user['user_password']) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['email'] = $user['user_email'];
        $_SESSION['user_permission'] = $user['user_permission'];

        if ($user['user_permission'] == 1) {
            header("Location: ./LoginForm.php");
            exit(); // Return the URL for admin fix404
        } else {
            header("Location: ../landingPage/landingPage.php");
            exit(); // Return the URL for user
        }
    } else {
        echo 'Wrong email or password.';
    }

    $stmt->close();
}

$conn->close();




?>

