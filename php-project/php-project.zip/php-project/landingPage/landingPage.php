<?php include("../navbar/navbar.php");?>
<?php include("../cart/cart.php");?>
<?php include("zaidContante.php");?>
<?php include("rashaContante.php");?>
<?php include("../footer/footer.php");?>

